# Data-Analysis-using-power-bi
![data analysis - Power BI Desktop 23-08-2023 12 17 08 AM](https://github.com/padeshmukhhhhhhhhhhh/Data-Analysis-using-power-bi/assets/103956597/11f739f9-be1f-4e18-8708-9572a0cbfdbe)
