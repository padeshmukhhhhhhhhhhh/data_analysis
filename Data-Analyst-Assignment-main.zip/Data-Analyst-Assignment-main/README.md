# Data-Analyst-Assignment
![Screenshot (52)](https://github.com/padeshmukhhhhhhhhhhh/Data-Analyst-Assignment/assets/103956597/43102ea1-bd26-448c-965c-a1477700f2df)
