# Data-Analyst-project using excel

![Vrinda Store Data Analysis - Excel (Product Activation Failed) 20-08-2023 1 59 10 PM](https://github.com/padeshmukhhhhhhhhhhh/Data-Analyst-project/assets/103956597/424e76b2-4970-46a4-b608-bd77752ab5d1)

